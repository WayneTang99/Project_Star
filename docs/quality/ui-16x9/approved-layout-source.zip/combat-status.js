// 只读表现示例，不连接游戏命令或替代确定性战斗复算。
const scenarios=[['mixed','综合状态'],['normal','正常'],['haste','疾速'],['slow','迟缓'],['stop','禁锢'],['cancel','疾速＋迟缓'],['charge','充能'],['dots','灼伤／中毒'],['flight','飞行'],['rage','狂暴'],['destroyed','摧毁']];
let scenario='mixed',elapsed=0,lastFrame=0;
const demoCards=new Map();
const playerDot={health:450,max:600,armor:25,burn:8,poison:4,burnClock:0,poisonClock:0};
const enemyDot={health:600,max:600,armor:25,burn:18,poison:10,burnClock:0,poisonClock:0};
function tier(el,level){el.dataset.level=String(Math.max(1,Math.min(5,level)));}
const originalTooltip=showTooltip;
showTooltip=function(el){originalTooltip(el);tier(document.querySelector('#tooltip'),cards[el.dataset.card].level);};
const originalStage=drawStage;
drawStage=function(){
 originalStage();
 const side=document.querySelector('.stage-side'),stageLevel=mode==='shop'?4:mode==='battle'?1:2; tier(side,stageLevel);
 side.querySelector('.eyebrow').textContent=`第3回合 · ${stageLevel}级${mode==='shop'?'商店':mode==='battle'?'怪物遭遇':'遭遇'}`;
 document.querySelectorAll('.encounter').forEach((el,i)=>{const level=[4,2,1][i];tier(el,level);el.insertAdjacentHTML('afterbegin',`<span class="rank-caption">${level}级</span>`);});
 if(mode==='encounter'){
  const mentor=document.createElement('button');mentor.className='encounter';mentor.style.setProperty('--scene-art',`url('${ASSETS.forest}')`);tier(mentor,1);
  mentor.innerHTML='<span class="rank-caption">导师 · 1级</span><div><strong>大主教</strong><small>传授圣骑士技能<br>导师边框使用本次等级色</small></div>';
  mentor.onclick=()=>toast('大主教 · 1级导师 · 传授1级圣骑士技能（表现示例）');document.querySelector('.stage-body').append(mentor);
 }
 const monster=document.querySelector('.enemy-portrait');if(monster){tier(monster,1);monster.title='林地野猪 · 1级';monster.querySelector('strong').textContent='林地野猪 · 1级';}
 if(mode==='battle'){
  document.querySelector('.battle-text p').textContent='发动条与状态反馈示例 · 可暂停逐项查看';
  document.querySelector('.battle-text').insertAdjacentHTML('beforeend','<div class="dot-row enemy-status" aria-label="敌方英雄状态"></div>');
  document.querySelector('#play').textContent='播放动效';document.querySelector('#skip').textContent='重置示例';document.querySelector('#skip').onclick=()=>applyScenario(scenario);
 }
 document.querySelector('.combat-studio').hidden=mode!=='battle';
 updateCombat();
};
const studio=document.createElement('section');studio.className='combat-studio';studio.setAttribute('aria-label','战斗表现预览');
studio.innerHTML=`<div class="studio-head"><strong>战斗表现预览</strong><small>细光带显示发动进度，等级框始终保留</small></div><div class="scenario-list">${scenarios.map(([key,name])=>`<button data-scenario="${key}" type="button">${name}</button>`).join('')}</div><div class="status-guide"><span><b>↗ 疾速</b> · 进度 ×2</span><span><b>↘ 迟缓</b> · 进度 ×0.5</span><span><b>▣ 禁锢</b> · 进度暂停</span><span><b>✦ 充能</b> · 进度立即前移</span></div><p class="studio-note">状态与等级分别编码；疾速和迟缓并存时进度 ×1，禁锢优先暂停。灼伤与中毒属于英雄：灼伤每0.6秒结算、先扣护甲并衰减；中毒每1秒结算、无视护甲且不衰减。此页只演示表现，不是正式战斗结果。</p>`;
document.querySelector('.board-section').before(studio);
const legend=document.createElement('div');legend.className='level-legend';legend.innerHTML='等级边框 '+[1,2,3,4,5].map((level,i)=>`<span data-level="${level}">${level}级 · ${['银灰','蓝','紫','橙','红'][i]}</span>`).join('')+'<small>卡牌 · 技能 · 遭遇 · 怪物 · 导师；英雄不使用等级色</small>';
document.querySelector('.modebar').after(legend);
document.querySelector('#hero-skills').innerHTML=[['smite','至圣斩',4],['defend','捍卫',1],['charge','冲撞',2]].map(([art,name,level])=>`<span class="skill" data-level="${level}" title="${name} · ${level}级" role="img" aria-label="${name}，${level}级" style="--skill-art:url('${ASSETS[art]}')"></span>`).join('')+'<small>技能边框表示等级</small>';
document.querySelector('.hero-panel .bars').insertAdjacentHTML('afterend','<div class="dot-row player-status" aria-label="己方英雄战斗状态"></div>');
document.querySelector('.previewtag').textContent='等级与战斗状态 · HTML草案';
document.querySelectorAll('[data-scenario]').forEach(button=>button.onclick=()=>applyScenario(button.dataset.scenario));
function applyScenario(next){
 scenario=next;playing=false;elapsed=0;demoCards.clear();
 [playerDot,enemyDot].forEach((state,i)=>Object.assign(state,{health:i?600:450,armor:25,burn:i?18:8,poison:i?10:4,burnClock:0,poisonClock:0}));
 battlefieldKeys.forEach((key,i)=>{
  const state={remaining:cards[key].cool*(.62-i*.09),haste:0,slow:0,stop:0,flight:next==='flight',rage:next==='rage',destroyed:false};
  if(next==='haste'||next==='cancel')state.haste=4;
  if(next==='slow'||next==='cancel')state.slow=4;
  if(next==='stop')state.stop=3;
  if(next==='mixed'){if(i===0){state.haste=3;state.flight=true;}if(i===1)state.slow=4;if(i===2)state.stop=3;if(i===3){state.haste=3;state.slow=2;}if(i===4)state.rage=true;}
  if(next==='destroyed'&&i===2)state.destroyed=true;
  if(next==='charge'&&i===1)state.remaining=Math.max(0,state.remaining-1);
  demoCards.set(key,state);
 });
 document.querySelectorAll('[data-scenario]').forEach(button=>{const selected=button.dataset.scenario===next;button.classList.toggle('active',selected);button.setAttribute('aria-pressed',String(selected));});
 updateCombat();
 if(next==='charge')pulse(document.querySelector('#battlefield [data-card="ascendant"]'),'charged',1000);
}
function pill(kind,symbol,name,seconds){return `<span class="combat-pill ${kind}" title="${name}，剩余${seconds.toFixed(1)}秒">${symbol}<em>${name}</em> ${seconds.toFixed(1)}s</span>`;}
function updateCombat(){
 const active=mode==='battle';
 document.querySelectorAll('#battlefield .card').forEach(el=>{
  const key=el.dataset.card,state=demoCards.get(key);if(!state)return;
  let layer=el.querySelector('.battle-layer');if(!layer){layer=document.createElement('div');layer.className='battle-layer';el.append(layer);}
  layer.hidden=!active;
  const speed=state.stop>0?0:state.haste>0&&state.slow>0?1:state.haste>0?2:state.slow>0?.5:1;
  el.classList.toggle('is-haste',active&&speed===2);el.classList.toggle('is-slow',active&&speed===.5);el.classList.toggle('is-stopped',active&&state.stop>0);el.classList.toggle('is-destroyed',active&&state.destroyed);
  el.classList.toggle('is-flying',active&&state.flight);el.classList.toggle('is-berserk',active&&state.rage);
  if(!active)return;
  if(state.destroyed){layer.innerHTML='<span class="destroyed-label">× 已摧毁</span>';return;}
  const total=cards[key].cool,percent=Math.max(0,Math.min(100,(1-state.remaining/total)*100));
  layer.innerHTML=`<div class="activation-track" role="progressbar" aria-label="${cards[key].name}发动进度" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round(percent)}"><div class="activation-fill" style="--ready:${percent}%"></div></div><span class="activation-clock" title="剩余冷却${state.remaining.toFixed(1)}秒 · 当前速度×${speed}">${state.stop>0?'Ⅱ ':''}${state.remaining.toFixed(1)}s</span><div class="combat-pills">${state.haste>0?pill('haste','↗','疾速',state.haste):''}${state.slow>0?pill('slow','↘','迟缓',state.slow):''}${state.stop>0?pill('stop','▣','禁锢',state.stop):''}${state.flight?'<span class="combat-pill fly" title="飞行：新受迟缓和禁锢时长减半">↟<em>飞行</em></span>':''}${state.rage?'<span class="combat-pill rage" title="狂暴：自身发动的伤害及施毒、灼伤量提高20%">✹<em>狂暴</em></span>':''}</div>${state.stop>0?'<span class="combat-lock"></span>':''}<span class="activation-flash"></span><span class="charge-pop">✦ 充能 +1秒</span>`;
 });
 const dots=active&&(scenario==='dots'||scenario==='mixed');
 renderDotRow(document.querySelector('.player-status'),playerDot,dots);
 renderDotRow(document.querySelector('.enemy-status'),enemyDot,dots);
 const playerLabel=document.querySelector('.hero-panel .bars .bar-label'),playerFill=document.querySelector('.hero-panel .bars .bar-fill');
 playerLabel.textContent=`${playerDot.health} / 600`;playerFill.style.setProperty('--progress',`${playerDot.health/6}%`);
 const armor=document.querySelector('.hero-right .stats b');armor.textContent=playerDot.armor;
 if(active){document.querySelector('#enemy-label').textContent=`${enemyDot.health} / 600`;document.querySelector('#enemy-health').style.setProperty('--progress',`${enemyDot.health/6}%`);document.querySelector('#play').textContent=playing?'暂停':'播放动效';document.querySelector('#battle-status').textContent=playing?'交锋中':'表现预览';}
}
function renderDotRow(row,state,visible){
 if(!row)return;row.hidden=!visible;if(!visible)return;
 for(const [kind,symbol,name,amount,period] of [['armor','◇','护甲',state.armor,''],['burn','♨','灼伤',state.burn,'0.6s'],['poison','♧','中毒',state.poison,'1.0s']]){
  if(kind==='armor'&&row.classList.contains('player-status'))continue;
  let chip=row.querySelector(`.${kind}`);if(!chip){chip=document.createElement('span');chip.className=`dot-chip ${kind}`;row.append(chip);}
  chip.title=kind==='burn'?'每0.6秒伤害，先扣护甲；结算后灼伤-1':kind==='poison'?'每1秒伤害，无视护甲；不衰减':'承受普通伤害与灼伤伤害时优先扣除';
  chip.innerHTML=`${symbol} ${name} <b>${amount}</b>${period?`<small>／${period}</small>`:''}`;
 }
}
function pulse(el,cls,time=500){if(!el)return;el.classList.remove(cls);void el.offsetWidth;el.classList.add(cls);setTimeout(()=>el.classList.remove(cls),time);}
function tickDots(state,row,delta){
 if(scenario!=='dots'&&scenario!=='mixed')return;
 state.burnClock+=delta;state.poisonClock+=delta;
 if(state.burnClock>=.6){state.burnClock-=.6;const damage=state.burn,absorbed=Math.min(state.armor,damage);state.armor-=absorbed;state.health=Math.max(0,state.health-damage+absorbed);state.burn=Math.max(0,state.burn-1);pulse(row?.querySelector('.burn'),'tick',350);}
 if(state.poisonClock>=1){state.poisonClock-=1;state.health=Math.max(0,state.health-state.poison);pulse(row?.querySelector('.poison'),'tick',350);}
}
playBattle=function(){playing=!playing;document.querySelector('#battlefield').classList.toggle('battle-active',playing);updateCombat();};
finishBattle=function(){applyScenario(scenario);toast('已重置战斗表现示例');};
function animate(now){
 const delta=Math.min(.05,lastFrame?(now-lastFrame)/1000:0);lastFrame=now;
 if(playing&&mode==='battle'&&!document.hidden){
  elapsed+=delta;
  for(const [key,state] of demoCards){
   if(state.destroyed)continue;
   const speed=state.stop>0?0:state.haste>0&&state.slow>0?1:state.haste>0?2:state.slow>0?.5:1;
   state.remaining=Math.max(0,state.remaining-delta*speed);
   for(const flag of ['haste','slow','stop'])state[flag]=Math.max(0,state[flag]-delta);
   if(state.remaining===0){state.remaining=cards[key].cool;pulse(document.querySelector(`#battlefield [data-card="${key}"]`),'has-fired');}
  }
  tickDots(playerDot,document.querySelector('.player-status'),delta);tickDots(enemyDot,document.querySelector('.enemy-status'),delta);updateCombat();
 }
 requestAnimationFrame(animate);
}
hideTooltip(true);applyScenario('mixed');setMode('battle');requestAnimationFrame(animate);

// 仅移动原版组件和适配16:9画布，保留原版交互与所有表现样式。
document.body.classList.add('layout-only');
const layoutApp=document.querySelector('.app');
const layoutFrame=document.createElement('div');layoutFrame.id='layout-frame';
layoutApp.before(layoutFrame);layoutFrame.append(layoutApp);
const layoutGrid=document.createElement('div');layoutGrid.className='layout-grid';
const layoutSidebar=document.createElement('aside');layoutSidebar.className='layout-sidebar';
const layoutMain=document.createElement('div');layoutMain.className='layout-main';
layoutGrid.append(layoutSidebar,layoutMain);layoutApp.append(layoutGrid);
layoutMain.append(document.querySelector('#stage'),...document.querySelectorAll('.board-section'));
const layoutEnemy=document.createElement('section');layoutEnemy.className='layout-enemy';layoutEnemy.hidden=true;
const layoutTools=document.createElement('div');layoutTools.className='layout-tools';
layoutTools.append(document.querySelector('.level-legend'),document.querySelector('.combat-studio'),document.querySelector('.prototype-controls'),document.querySelector('.bottomline'));
layoutSidebar.append(layoutEnemy,document.querySelector('.hero-panel'),layoutTools);
// 怪物自己的真实槽位；新增预览条目也使用原cardHTML，不修改已有卡牌样例。
ASSETS.beastHide='../../../art/ui/card-face/artwork/beast_hide-illustration-refresh.png';
cards.monsterHide={name:'兽皮',art:'beastHide',span:1,level:1,elements:['general'],effects:[],value:4,cool:null,tags:['小型','材料','无属性'],desc:['<b class="keyword">拾取</b>　获得此卡牌后，价值增加2。']};
cards.monsterBoar={...cards.boar,level:1,value:4,effects:[['damage','20']],desc:['<b class="keyword">发动</b>　造成20 × 己方英雄当前生命比例的普通伤害。']};
const layoutOriginalStage=drawStage;
drawStage=function(){
 layoutEnemy.replaceChildren();layoutEnemy.hidden=true;
 const stage=document.querySelector('#stage');stage.classList.remove('monster-stage');
 layoutOriginalStage();
 if(mode==='battle'){
  // 摘要组件原封不动移到次要区域，主阶段显示怪物自己的战场。
  layoutEnemy.append(stage.querySelector('.battle-summary'));layoutEnemy.hidden=false;
  stage.classList.add('monster-stage');
  stage.innerHTML='<div class="board battlefield" id="monster-battlefield" aria-label="怪物野猪的战场区">'+['monsterHide','monsterHide','monsterBoar'].map(key=>cardHTML(key)).join('')+Array.from({length:6},(_,i)=>`<div class="empty" data-slot="${i+5}"><span>✧</span></div>`).join('')+'</div>';
  bindCards();
 }
};
function fitLayout(){
 const width=Math.min(innerWidth,innerHeight*16/9);
 layoutFrame.style.width=width+'px';layoutFrame.style.height=width*9/16+'px';
 layoutApp.style.transform=`scale(${width/1600})`;
 if(activeCard?.isConnected)positionTooltip(activeCard);
}
addEventListener('resize',fitLayout);
drawStage();fitLayout();
